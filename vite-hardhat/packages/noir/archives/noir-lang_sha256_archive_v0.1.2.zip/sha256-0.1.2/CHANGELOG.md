# Changelog

## [0.1.2](https://github.com/noir-lang/sha256/compare/v0.1.1...v0.1.2) (2025-02-13)


### Features

* **performance:** Always inline certain small methods ([#13](https://github.com/noir-lang/sha256/issues/13)) ([96c43cc](https://github.com/noir-lang/sha256/commit/96c43ccf8fd92502e0e83836ecde0f89e2b09799))

## [0.1.1](https://github.com/noir-lang/sha256/compare/v0.1.0...v0.1.1) (2025-02-04)


### Features

* Add a sha256 implementation which is optimized for unconstrained runtime ([#9](https://github.com/noir-lang/sha256/issues/9)) ([a333d3c](https://github.com/noir-lang/sha256/commit/a333d3cd86380cf191849b4daadf94bb1b1f2ec9))

## 0.1.0 (2025-01-21)


### Features

* Initial release
